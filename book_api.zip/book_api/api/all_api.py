from api.book import Book


class AllApi(Book):
    pass


api = AllApi()

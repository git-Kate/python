class PublicVariable(object):
    
    def __init__(self):
        self.setting=""                    # 环境
        self.book_id=0       


variable=PublicVariable()
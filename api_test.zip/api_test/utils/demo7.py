import requests

class Test:
    def __init__(self):
        self.host="http://106.14.37.200:8000/"
        self.headers={"authorization":""}

    def login(self,username,password):
        print(username,password)
        res=requests.post(f"{self.host}api-token-auth/",{"username":username,"password":password})
        self.headers['authorization']=f"Token {res.json()['token']}"
        print(res.json())

    def get(self,url,headers=None):
        if headers:
            self.headers.update(headers)   
        res=requests.get(f"{self.host}{url}",headers=self.headers)
        print(res.json())

if __name__ == '__main__':
    t = Test()
    t.login("admin","123456")
    t.get("api/book/?book_name=&format=json")


# import urllib3
# urllib3.disable_warnings()

# requests.post("https://testerhome.com/account/sign_in",{"username":"zhaowen","password":"123456"},verify=False)   #如果是https请求加verify=False，移除SSL认证


# res=requests.post("http://106.14.37.200:8000/api-token-auth/",{"username":"admin","password":"123456"},verify=False)
# print(res.json())
# token=f"Token {res.json()['token']}"
# res2=requests.get("http://106.14.37.200:8000/api/book/?book_name=&format=json",headers={"authorization":token})
# print(res2.json())

# response = requests.post("http://106.14.37.200:8000/api-token-auth/",
#                          {"username": "admin", "password": "123456"})
# print(response.json())
# authorization = response.json()['token']
# res2=requests.get("http://106.14.37.200:8000/api/book/?book_name=&format=json", headers={"authorization":"Token "+authorization})
# print(res2.json())

# 

# token="Token "+response.json()['token']
# response2=requests.get("http://106.14.37.200:8000/api/book/?book_name=&format=json",headers={"authorization":token})
# print(response2.json())

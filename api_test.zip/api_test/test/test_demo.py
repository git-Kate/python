import pytest
import allure
from  utils.custom_logger import logger_cls


@pytest.fixture(scope='class', autouse=True)  #autouse,自动执行
def front():
    logger_cls.info("类级别的-前置条件")
    return "111"



@pytest.fixture(scope='class', autouse=True)
def after():
    yield after
    logger_cls.info("类级别的-后置条件")

class Test_01:

    @allure.feature("测试一")
    def test_01(self):
        print("运行测试一")
        assert 1 == 2, "预期结果不等于实际结果"

    @allure.feature("测试二")
    def test_02(self):
        print("运行测试二")
        assert 1 == 2, "预期结果不等于实际结果"

    def test_03(self,front):
        logger_cls.info("测试三")
        assert front == 3, f"{front}结果不相等3"

    def test_4(self):
        logger_cls.info("测试4")
        a = True
        assert a == True, f"结果不相等3"

    def test_5(self):
        """测试一"""
        logger_cls.info("测试5")
        assert "a" in "abc", f"不包含"


